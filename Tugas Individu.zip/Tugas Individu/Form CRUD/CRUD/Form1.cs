﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace CRUD
{
    public partial class Form1 : Form
    {
        OleDbConnection koneksi = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\Backup Semester 4\Pemvis\Form\CRUD\bin\Debug\dbmenu.mdb");
        
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbmenuDataSet1.tb_menu' table. You can move, or remove it, as needed.
            koneksi.Open();
            try
            {
                string query = "select * from tb_menu";
                OleDbCommand command = new OleDbCommand(query, koneksi);
                DataSet ds = new DataSet();
                OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                adapter.Fill(ds, "res");
                dataGridView1.DataSource = ds.Tables["res"];
                adapter.Dispose();
                command.Dispose();
            }
            catch (Exception)
            {
                MessageBox.Show("Gagal menampilkan Data");
            }

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

       

        private void button1_Click(object sender, EventArgs e) //simpan
        {
           
            
            try
            {
                string sql = string.Format("insert into tb_menu values ('{0}','{1}','{2}')", idmenu.Text, nama.Text, harga.Text);
                OleDbCommand command = new OleDbCommand(sql, koneksi);
                command.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil disimpan");
                command.Dispose();
            }
            catch (Exception err)
            {
                MessageBox.Show("Data Gagal disimpan" + err.Message.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)//edit
        {
            try
            {
                string sql = string.Format("update [tb_menu] set nama='" + this.nama.Text + "', idmenu='" + this.idmenu.Text + "', harga ='" + this.harga.Text + "' where nama='"+ this.nama.Text +"'");
                OleDbCommand command = new OleDbCommand(sql, koneksi);
                command.ExecuteNonQuery();
                MessageBox.Show("Data Berhasil diedit");
                command.Dispose();
            }
            catch (Exception)
            {
                MessageBox.Show("Data Gagal diedit");
            }

        }
        private void button3_Click(object sender, EventArgs e)//hapus
        {
            try
            {
                string sql = string.Format("delete from tb_menu where nama ='" + nama.Text + "'");
                OleDbCommand command = new OleDbCommand(sql, koneksi);
                command.ExecuteNonQuery();
                MessageBox.Show("Data Dihapus");
                command.Dispose();
            }
            catch (Exception)
            {
                MessageBox.Show("Data Gagal Dihapus");
            }
        }
        private void button2_Click(object sender, EventArgs e)//refresh
        {
            try
            {
                string query = "select * from tb_menu";
                OleDbCommand command = new OleDbCommand(query, koneksi);
                DataSet ds = new DataSet();
                OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                adapter.Fill(ds, "res");
                dataGridView1.DataSource = ds.Tables["res"];
                adapter.Dispose();
                command.Dispose();
            }
            catch (Exception)
            {
                MessageBox.Show("Gagal menampilkan Data");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            idmenu.Text = row.Cells[0].Value.ToString();
            nama.Text = row.Cells[1].Value.ToString();
            harga.Text = row.Cells[2].Value.ToString();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
