﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_pengiriman
{
    public partial class form4 : Form
    {
        public form4()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //transaksi pengiriman
            Form0 f0 = new Form0();
            f0.Show();
            this.Hide();
        }
    }
}
